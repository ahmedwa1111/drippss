
  # E-commerce website for Drippss

  This is a code bundle for E-commerce website for Drippss. The original project is available at https://www.figma.com/design/keamjHhsmlnjJ4KT6Ue8NO/E-commerce-website-for-Drippss.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  